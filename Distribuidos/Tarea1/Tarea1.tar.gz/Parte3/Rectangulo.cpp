#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include "Coordenada.h"
#include "Rectangulo.h"

using namespace std;

Rectangulo::Rectangulo(Coordenada punto1, Coordenada punto2){
	superiorIzq = punto1;
	inferiorDer = punto2;
}

Rectangulo::Rectangulo() : superiorIzq(0,0), inferiorDer(0,0)
{ }

/*Rectangulo::Rectangulo(double xSupIzq, double ySupIzq, double xInfDer, double 
	yInfDer):superiorIzq(xSupIzq, ySupIzq), inferiorDer(xInfDer, yInfDer)
{ }*/

double Rectangulo::obtenerArea(){
	double alto;
	double ancho;
	alto = superiorIzq.obtenerY() - inferiorDer.obtenerY();
	ancho = inferiorDer.obtenerX() - superiorIzq.obtenerX();
    double area = alto*ancho;
	//cout << "El área del rectángulo es = " << area << endl;
    return area;
}

void Rectangulo::imprimeEsq(){
	cout << "Para la esquina superior izquierda.\n";
	cout << "x = " << superiorIzq.obtenerX() << " y = " << superiorIzq.obtenerY() << endl;
	cout << "Para la esquina inferior derecha.\n";
	cout << "x = " << inferiorDer.obtenerX() << " y = " << inferiorDer.obtenerY() << endl;   
}
Coordenada Rectangulo::obtieneSupIzq(){
	return superiorIzq;
}

Coordenada Rectangulo::obtieneInfDer(){
	return inferiorDer;
}