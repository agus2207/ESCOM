#include "header.h"
#include "Archivo.h"
#include "SocketDatagrama.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "string.h"

#define puertoServer 7200
char buffer[BUF_SIZE];
long position;

using namespace std;

struct  messageSC{
    long sup;
    long inf;
};

void computeLPSArray(char* pat, int M, int* lps); 
// Prints occurrences of txt[] in pat[] 
int KMPSearch(char* pat, char* txt) 
{ 
    int M = strlen(pat); 
    int N = strlen(txt); 
  
    // create lps[] that will hold the longest prefix suffix 
    // values for pattern 
    int lps[M]; 
  
    // Preprocess the pattern (calculate lps[] array) 
    computeLPSArray(pat, M, lps); 
  
    int i = 0; // index for txt[] 
    int j = 0; // index for pat[] 
    while (i < N) { 
        if (pat[j] == txt[i]) { 
            j++; 
            i++; 
        } 
  
        if (j == M) { 
            printf("Found pattern at index %d\n", i - j);
            printf("Texto encontrado: %s\n", pat); 
            return i-j; 
            //j = lps[j - 1]; 
        } 
  
        // mismatch after j matches 
        else if (i < N && pat[j] != txt[i]) { 
            // Do not match lps[0..lps[j-1]] characters, 
            // they will match anyway 
            if (j != 0) 
                j = lps[j - 1]; 
            else
                i = i + 1; 
        } 
    } 
    return -1;
} 

int lcs( unsigned char *X, unsigned char *Y, int m, int n ) 
{ 
   int L[m+1][n+1]; 
   int i, j; 
   char Res[1000];
   
   /* Following steps build L[m+1][n+1] in bottom up fashion. Note  
      that L[i][j] contains length of LCS of X[0..i-1] and Y[0..j-1] */
   for (i=0; i<=m; i++) 
   { 
     for (j=0; j<=n; j++) 
     { 
       if (i == 0 || j == 0){
            L[i][j] = 0;
            Res[i] = X[L[i][j]];  
       }  
   
       else if (X[i-1] == Y[j-1]){
           L[i][j] = L[i-1][j-1] + 1;
           Res[i] = X[L[i-1][j-1]+1];
       }  
   
       else
         L[i][j] = max(L[i-1][j], L[i][j-1]); 
     } 
   } 
     
   /* L[m][n] contains length of LCS for X[0..n-1] and Y[0..m-1] */

   for(i = 0; i < L[m][n]; i++){
       printf("%c", Res[i]);
   }
   printf("\n");
   return L[m][n]; 
} 
   
/* Utility function to get max of 2 integers */
int max(int a, int b) 
{ 
    return (a > b)? a : b; 
} 

/**/
int busqueda(unsigned char *b,unsigned char *c,long n,long m,int max){
	long i,j,k,l;
	char aux[1000],aux2[100];
	int index;
	int longMax=0;
	int indexMax;
	for(i=0;i<n;i++){
		for(k=0; b[k + i]!=' ' && k+i<n; k++){
			aux[k] = b[k + i];  
		}
		aux[k] = '\0';
		//puts(aux);
		//getchar();
		i+=k;
		
		index = 0;
		l = 0;
		while(index != -1){
			index = KMPSearch(aux, (char*)(c));
			strcat(aux," ");
			for(; b[k + i]!=' ' && k+i<n; k++){
				aux2[k] = b[k + i];  
			}
			strcat(aux,aux2);
			//getchar();
			if(index != -1){
				j=0;
			
				while(b[i + j] == c[index + j]){
					//
				
					j++;
				}
				if(longMax < j){
					longMax = j;
					indexMax = index; 
				}
				//printf("\n%d %d",longMax,indexMax);
			}

		}
		
	}
	putchar('\n');
	for(i=0; i<longMax; i++){
		printf("%c",c[i + indexMax]);
	}
	printf("\n%d %d",longMax,indexMax);
	return indexMax;
}

    

  
// Fills lps[] for given patttern pat[0..M-1] 
void computeLPSArray(char* pat, int M, int* lps) 
{ 
    // length of the previous longest prefix suffix 
    int len = 0; 
  
    lps[0] = 0; // lps[0] is always 0 
  
    // the loop calculates lps[i] for i = 1 to M-1 
    int i = 1; 
    while (i < M) { 
        if (pat[i] == pat[len]) { 
            len++; 
            lps[i] = len; 
            i++; 
        } 
        else // (pat[i] != pat[len]) 
        { 
            // This is tricky. Consider the example. 
            // AAACAAAA and i = 7. The idea is similar 
            // to search step. 
            if (len != 0) { 
                len = lps[len - 1]; 
  
                // Also, note that we do not increment 
                // i here 
            } 
            else // if (len == 0) 
            { 
                lps[i] = 0; 
                i++; 
            } 
        } 
    } 
} 

int doRead(mensaje* mS, Archivo a){
    cout << "READ" << endl;
    a.readFile(buffer);  

    mS->opcode = READ;
    mS->offset = position;
    mS->count = a.obtieneNBytes();

    if(a.obtieneNBytes() > 0){
        strcpy(mS->name, a.obtieneNombre());
        memcpy(mS->data, buffer, a.obtieneNBytes());       
    } else{
        cout << "Cerrando archivo MODO lectura" << endl;
        a.closeFiles();
    }
    
    return OK;
}

int doWrite(mensaje* mE, Archivo a){
    if(mE->count > 0){
        memcpy(buffer, mE->data, mE->count);
        a.writeFile(buffer, mE->count);
    } else{
        cout << "Cerrando archivo MODO Escritura" << endl; 
        a.closeFiles();
    }
    return OK;
}

long limpiarArchivo(char * archivo,unsigned char ** b){
	FILE *f=NULL;
	f=fopen(archivo,"r");
	long sz;
	int prev=ftell(f);//medimos el tamaño del archivo
    fseek(f,0L,SEEK_END);
    sz = (long)ftell(f);
    fseek(f,prev,SEEK_SET);
    //printf("El archivo a leer mide %ld bytes\n",sz);
    unsigned char * a = (unsigned char*)malloc(sizeof(unsigned char)*sz);
    *b = (unsigned char*)malloc(sizeof(unsigned char)*sz);
    fread(a,1,sz,f);

	long i,j;
	
	for(i=0,j=0; i<sz; i++){
		if((a[i]>=65 && a[i]<=90) || islower((int)a[i])){
			(*b)[j] = a[i];
			j++;
		}else if(a[i]==32){
			if((*b)[j - 1] == 32){
				;
			}else{
				(*b)[j] = a[i];
				j++;
			}
		}else if(a[i]==195){
			i++;
			switch (a[i]){
				case 0xa1:
					(*b)[j] = 'a';
					break;
				case 0xa9:
					(*b)[j] = 'e';
					break;
				case 0xad:
					(*b)[j] = 'i';
					break;
				case 0xb3:
					(*b)[j] = 'o';
					break;
				case 0xba:
					(*b)[j] = 'u';
					break;
				case 0xb1:
					(*b)[j] = 'n';
					break;
				default:
					(*b)[j] = ' ';
					break;
			}
			j++;
		}else{
			if((*b)[j - 1] == 32){
				;
			}else{
				(*b)[j] = ' ';
				j++;
			}
		}
	}
	printf("%ld",i);
	fclose(f);
	free(a);
	return j;
}

char* concat(const char *s1, const char *s2)
{
    char *result = (char*)malloc(strlen(s1) + strlen(s2) + 1); 
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}

int main(int argc, char const *argv[])
{
    mensaje mEntrada = mensaje();
    mensaje mSalida = mensaje();
    int r;

    SocketDatagrama socketDatagrama(puertoServer);
    Archivo archivo(0);
    position = 0;
    int numArchivos = 0;

    while(1){
        cout << "------" << endl;
        PaqueteDatagrama paqueteRecibido(sizeof(mensaje));
        socketDatagrama.recibe(paqueteRecibido, 0, 500000);
 
        memcpy((mensaje*)&mEntrada, paqueteRecibido.obtieneDatos(), paqueteRecibido.obtieneLongitud());
        
        cout << "Accion: " << mEntrada.opcode << endl;
        cout << "Count: " << mEntrada.count << endl;

        if(mEntrada.opcode == 4)
            numArchivos++;

        //Fin del archivo
        switch (mEntrada.opcode)
        {
            case READ:
                r = doRead(&mSalida, archivo);
                break;
            case WRITE:
                r = doWrite(&mEntrada, archivo);
                break;
            case CREATE:
                r = archivo.openFile(mEntrada.name, mEntrada.opcode);
                r = doWrite(&mEntrada, archivo);
                break;
            case SOL:
                r = archivo.openFile(mEntrada.name, READ);
                r = doRead(&mSalida, archivo);
                break;
            default:
                r = E_BAD_OPCODE;
        }
        
        memset(buffer, 0, sizeof buffer);
        mSalida.result = r;

        PaqueteDatagrama paqueteRespuesta(sizeof(mensaje));
        paqueteRespuesta.inicializaDatos((char *)&mSalida);
        paqueteRespuesta.inicializaIp(paqueteRecibido.obtieneDireccion());
        paqueteRespuesta.inicializaPuerto(paqueteRecibido.obtienePuerto());
        
        socketDatagrama.envia(paqueteRespuesta);

        position += archivo.obtieneNBytes();
        //cout << "Position: " << position << endl;
        
        if(numArchivos == 2)
            break;
    }

    cout << "Analisis" << endl;
	
	unsigned char *cadena1, *cadena2;
	int t1, t2;
	t1 = limpiarArchivo("copiaA1.txt", &cadena1);
	t2 = limpiarArchivo("copiaA2.txt", &cadena2);

	cout << "------" << endl;

	PaqueteDatagrama paqueteRecibido(sizeof(messageSC));
    socketDatagrama.recibe(paqueteRecibido);
    
    struct messageSC *limites = (struct messageSC *) paqueteRecibido.obtieneDatos();
    cout << limites->inf << " - " << limites->sup << endl;   

    char* cadenaBuscar = "";
    char arr[40];
    /*for(int i = limites->inf; i < limites->sup; i++){
       
        //KMPSearch(cadenaBuscar, ); 
    }*/

    KMPSearch("que produce el metal al raspar la tierra Un sonido que le era muy familiar", (char*) cadena1); 
	

    busqueda(cadena1,cadena2, t1, t2, t2);

    return 0;
}