#include "header.h"
#include "Archivo.h"
#include "SocketDatagrama.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <string>
#include "string.h"

#define puertoServer 7200
char buffer[BUF_SIZE];
using namespace std;

// client to server ./cliente 1 hola.txt 192.168.1.245 copiaIP.txt
// server to client ./cliente 2 copia.jpg 192.168.1.245 perfil.jpg

int main(int argc, char *argv[])
{
    printf("Modo de operacion: %s archivo: %s IP: %s \n", argv[1], argv[2], argv[3]);
    // Verificamos el número de parametros ingresados
    if(argc != 5){
        exit(-1);
    }
    mensaje mEntrada = mensaje();
    mensaje mSalida = mensaje();
    
    int r;

    SocketDatagrama socketDatagrama(0);
    Archivo archivo(0);
    long position = 0;


    PaqueteDatagrama paqueteEnviar(sizeof(mensaje));
    paqueteEnviar.inicializaIp(argv[3]);
    paqueteEnviar.inicializaPuerto(puertoServer);

    //Enviar archivo
    if(atoi(argv[1]) == 1){
        cout << "Enviando archivo " << argv[2] << endl;
        archivo.openFile(argv[2], READ);
        
        cout << "Nombre server: " << argv[4] << endl;
        int flagReenvio = 0;
        do{
            if(flagReenvio == 0){
                cout << position << endl;
                if(position > 0)
                    mSalida.opcode = WRITE;
                else
                    mSalida.opcode = CREATE;

                mSalida.offset = position;
                
                archivo.readFile(buffer);
                cout << "Bytes leídos: " << archivo.obtieneNBytes() << endl;
                
                if(archivo.obtieneNBytes() > 0){
                    strcpy(mSalida.name,argv[4]);
                    memcpy(mSalida.data, buffer, archivo.obtieneNBytes());
                } else{
                    archivo.closeFiles();
                }
                mSalida.count = archivo.obtieneNBytes();
            }
            flagReenvio = 0;
            
            paqueteEnviar.inicializaDatos((char *)&mSalida);    
            socketDatagrama.envia(paqueteEnviar);
            position += archivo.obtieneNBytes();

            PaqueteDatagrama paqueteRecibido(sizeof(mensaje));
            int timeout = socketDatagrama.recibe(paqueteRecibido, 0, 500000);
            if(timeout == 0){
                flagReenvio = 1;
            }

        }while(mSalida.count > 0);

    } else if(atoi(argv[1]) == 2){
        //Recibir archivo
        char * nombreArchivoSolicitado = argv[2];
        archivo.openFile(nombreArchivoSolicitado, WRITE);
        cout << "Solicitando archivo " << nombreArchivoSolicitado << endl;
        do
        {
            cout << position << endl;
            if(position > 0){
                mSalida.opcode = READ;
                paqueteEnviar.inicializaDatos((char *)&mSalida);    
                socketDatagrama.envia(paqueteEnviar);
            }else{
                mSalida.opcode = SOL;   
                strcpy(mSalida.name,argv[4]);

                paqueteEnviar.inicializaDatos((char *)&mSalida);    
                socketDatagrama.envia(paqueteEnviar);
            }
            
            PaqueteDatagrama paqueteRecibido(sizeof(mensaje));
            socketDatagrama.recibe(paqueteRecibido, 0, 500000);

            memcpy((mensaje*)&mEntrada, paqueteRecibido.obtieneDatos(), paqueteRecibido.obtieneLongitud());
            if(mEntrada.result != OK){
                cout << "Error al obtener el archivo" << endl;
                break;
            }

            if(mEntrada.count > 0){
                memcpy(buffer, mEntrada.data, mEntrada.count);
                archivo.writeFile(buffer, mEntrada.count);
            } else{
                cout << "Cerrando archivo MODO Escritura" << endl; 
                archivo.closeFiles();
                break;
            }
            position += archivo.obtieneNBytes();
        } while (mEntrada.count > 0);
    } else {
        cout << "Modo no encontrado" << endl;
    }
    cout << "Adios" << endl;
    return 0;
}
