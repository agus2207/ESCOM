/*Definiciones necesarias para los clientes y servidores*/
#define MAX_PATH     255
#define BUF_SIZE    1024
#define FILE_SERVER  243

/*Definiciones de las operaciones permitidas*/
#define CREATE 1
#define READ   2
#define WRITE  3
#define DELETE 4
#define SOL    5

/*Códigos de error*/
#define OK            0
#define E_BAD_OPCODE -1
#define E_BAD_PARAM  -2
#define E_IO         -3

/*Definición del formato del mensaje*/
struct mensaje
{
    long source;
    long dest;
    long opcode;
    long count;
    long offset;
    
    long extra1;
    long extra2;
    long result;
    char name[MAX_PATH];
    char data[BUF_SIZE];
};
