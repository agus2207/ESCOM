#include "SocketDatagrama.h"
#include "PaqueteDatagrama.h"
#include <iostream>
#include <string.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

SocketDatagrama::SocketDatagrama(int puerto)
{
    bzero((char *)&direccionLocal, sizeof(puerto));
    socketId = socket(AF_INET, SOCK_DGRAM, 0);
    direccionLocal.sin_family = AF_INET;
    direccionLocal.sin_addr.s_addr = INADDR_ANY;
    direccionLocal.sin_port = htons(puerto);
    bind(socketId, (struct sockaddr *)&direccionLocal, sizeof(direccionLocal));
}

int SocketDatagrama::envia(PaqueteDatagrama &paquete)
{
    unsigned int clilen = sizeof(direccionForanea);

    bzero((char *)&direccionForanea, sizeof(direccionForanea));
    direccionForanea.sin_family = AF_INET;
    direccionForanea.sin_addr.s_addr = inet_addr(paquete.obtieneDireccion());
    direccionForanea.sin_port = htons(paquete.obtienePuerto());

    //printf("Envia IP: %s Puerto: %d \n",
        //inet_ntoa(((struct sockaddr_in)direccionForanea).sin_addr),
        //ntohs(((struct sockaddr_in)direccionForanea).sin_port));

    return sendto(socketId, paquete.obtieneDatos(), paquete.obtieneLongitud(), 0, 
          (struct sockaddr *)&direccionForanea, clilen);
}

int SocketDatagrama::recibe(PaqueteDatagrama &paquete,  time_t segundos, suseconds_t microsegundos)
{
    timeout.tv_sec = segundos;
    timeout.tv_usec = microsegundos;

    int r = setsockopt(socketId, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout));

    unsigned int clilen = sizeof(direccionForanea);
    char * aux = new char[paquete.obtieneLongitud()];

    recvfrom(socketId, aux, paquete.obtieneLongitud(), 0, 
            (struct sockaddr *)&direccionForanea, &clilen);
    
    //printf("Recibe IP: %s Puerto: %d\n",
    //inet_ntoa(((struct sockaddr_in)direccionForanea).sin_addr),
        //ntohs(((struct sockaddr_in)direccionForanea).sin_port));

    paquete.inicializaIp(inet_ntoa(((struct sockaddr_in)direccionForanea).sin_addr));
    paquete.inicializaPuerto(ntohs(((struct sockaddr_in)direccionForanea).sin_port));
    paquete.inicializaDatos(aux);

    return r;
}

int SocketDatagrama::recibe(PaqueteDatagrama &paquete)
{
    unsigned int clilen = sizeof(direccionForanea);
    char * aux = new char[paquete.obtieneLongitud()];

    int r = recvfrom(socketId, aux, paquete.obtieneLongitud(), 0, 
            (struct sockaddr *)&direccionForanea, &clilen);
    
    //printf("Remitente: Puerto: %d Direccion IP: %s \n",
        //ntohs(((struct sockaddr_in)direccionForanea).sin_port),
        //inet_ntoa(((struct sockaddr_in)direccionForanea).sin_addr));

    paquete.inicializaIp(inet_ntoa(((struct sockaddr_in)direccionForanea).sin_addr));
    paquete.inicializaPuerto(ntohs(((struct sockaddr_in)direccionForanea).sin_port));
    paquete.inicializaDatos(aux);

    return r;
}


SocketDatagrama::~SocketDatagrama()
{

}