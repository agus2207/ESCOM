#ifndef ARCHIVO_H_
#define ARCHIVO_H_

class Archivo
{
    public:
        Archivo(int);
        int openFile(char *, int);
        void readFile(void* );
        void writeFile(void*, int);
        void closeFiles();
        int obtieneFileDescriptor();
        int obtieneNBytes();
        char* obtieneNombre();
    private:
        int nbytes;
        int fileDescriptor;
        char* nombreArchivo;
};
#endif